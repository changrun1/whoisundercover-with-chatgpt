let gameNumber = -2;
function getWord() {
  let gameNumber_ = -1;
  
  const xhr1 = new XMLHttpRequest();
  xhr1.open("GET", "/getNumber", true);
  xhr1.setRequestHeader("Content-Type", "application/json");
  xhr1.onreadystatechange = function() {
    if (xhr1.readyState === 4 && xhr1.status === 200) {
      gameNumber_ = xhr1.responseText
        if (gameNumber != gameNumber_){
            const xhr = new XMLHttpRequest();
            xhr.open("POST", "/getWord", true);
            xhr.setRequestHeader("Content-Type", "application/json");
            document.getElementById("result").innerHTML = "正在取得詞...";
            xhr.onreadystatechange = function() {
              if (xhr.readyState === 4 && xhr.status === 200) {
                //const response = JSON.parse(xhr.responseText);
                document.getElementById("result").innerHTML = xhr.responseText;
                if(xhr.responseText != "遊戲未開始"){
                  gameNumber = gameNumber_
                }
              }
            };
            xhr.send();
            
            
        }

    }
  };
  xhr1.send();
  

}

function newGame() {
  const xhr = new XMLHttpRequest();
  xhr.open("POST", "/newGame", true);
  xhr.setRequestHeader("Content-Type", "application/json");
  //document.getElementById("result").innerHTML = "正在刷新遊戲";
  xhr.onreadystatechange = function() {
    if (xhr.readyState === 4 && xhr.status === 200) {
      //const response = JSON.parse(xhr.responseText);
      //document.getElementById("result").innerHTML = xhr.responseText;
    }
  };
  xhr.send();
}


setInterval(getWord, 1000);
