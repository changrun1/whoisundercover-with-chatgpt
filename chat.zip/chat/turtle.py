import openai
import json

key1 = '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'
key2 = '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'
openai.api_key =  key1


def getRes(command):
    
    messages = [
        {"role": "system", "content": "接下來會有一則故事和一則敘述，請判斷敘述的真偽"},
        {"role": "system", "content": "請一定要調用函式不要直接講"},
        {"role": "system", "content": "晴天一個男人在一個很高的建築物下面看報紙，他看到一條消息後突然跑到建築物頂層，打開燈，然後跳下去自殺了。為什麼？"},
        {"role": "system", "content": "那男子是看管燈塔的人，報紙上說，由於燈塔的燈沒有開，導致了船隻發生了事故，男子爬上燈塔，開了燈，然後畏罪自殺。"},
        {"role": "user", "content": command}
    ]
    functions = [
        {
            "name": "result",
            "description": "根據故事的內容判斷",
            "parameters": {
                "description": "如果根據故事敘述為真，回傳'是'，否則回傳'否'，無法判斷或未提及回傳'無關'",
                "type": "object",
                "properties": {
                    "判斷": {
                        "type": "string",
                        "enum": ["是", "否", "無關"]
                    },
                },
                "required": ["判斷"],
            },
        },
      
    ]
    response = openai.ChatCompletion.create(
        model="gpt-3.5-turbo",
        messages=messages,
        functions=functions,
        function_call="auto", 
    )
    response["choices"][0]["message"]["content"]
    response_message = response["choices"][0]["message"]


    if response_message.get("function_call"):

        function_name = response_message["function_call"]["name"]
        return response_message["function_call"]["arguments"]

print(getRes("他打開燈之後立刻跳下去嗎"))