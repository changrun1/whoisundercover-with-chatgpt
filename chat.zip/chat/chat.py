import openai
import json

key1 = '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'
key2 = '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'
openai.api_key =  key1


def getTwoWords():
    
    messages = [
        {"role": "system", "content": "請生成十個生活常見的名詞，類型要相同，但又要不一樣"},
        {"role": "system", "content": "有時候可以想一些不常用但大家都知道的"},
        {"role": "system", "content": "詞盡量隨機一點不要重複"},
        #{"role": "system", "content": "十個詞的類型都要一樣，例如都是食物"},
        {"role": "system", "content": "請調用函式不要直接打出來結果"},
        #{"role": "user", "content": command}
    ]
    functions = [
        {
            "name": "result",
            "description": "生成十個生活常見的名詞",
            "parameters": {
                "type": "object",
                "properties": {
                    "詞1": {
                        "type": "string",
                    },
                    "詞2": {
                        "type": "string",
                    },
                    "詞3": {
                        "type": "string",
                    },
                    "詞4": {
                        "type": "string",
                    },
                    "詞5": {
                        "type": "string",
                    },
                    "詞6": {
                        "type": "string",
                    },
                    "詞7": {
                        "type": "string",
                    },
                    "詞8": {
                        "type": "string",
                    },
                    "詞9": {
                        "type": "string",
                    },
                    "詞10": {
                        "type": "string",
                    },
                },
                "required": ["詞1", "詞2","詞3", "詞4","詞5", "詞6","詞7", "詞8","詞9", "詞10"],
            },
        },
      
    ]
    response = openai.ChatCompletion.create(
        model="gpt-3.5-turbo",
        messages=messages,
        functions=functions,
        function_call="auto", 
        temperature=1,
        top_p=0.7,
    )
    response["choices"][0]["message"]["content"]
    response_message = response["choices"][0]["message"]


    if response_message.get("function_call"):

        function_name = response_message["function_call"]["name"]
        return response_message["function_call"]["arguments"]

