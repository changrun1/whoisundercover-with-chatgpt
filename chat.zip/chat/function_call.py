import openai
import json

key1 = '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'
key2 = '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'
openai.api_key =  key1


def run_conversation(command):
    
    messages = [
        {"role": "system", "content": "你是一個智慧居家系統，幫忙控制家裡的燈，不用做出除了控制燈以外的事"},
        {"role": "system", "content": "沒有要控制燈就呼叫函式但不要傳參數"},
        {"role": "system", "content": "晚上要關客廳燈"},
        {"role": "system", "content": "睡前要關房間燈"},
        {"role": "system", "content": "回家要開玄關燈"},
        {"role": "system", "content": "颱風關所有燈"},
        {"role": "system", "content": "出門關所有燈"},
        {"role": "system", "content": "其它自己判斷"},
        {"role": "user", "content": command}
    ]
    functions = [
        {
            "name": "change_light",
            "description": "改變電燈的狀態",
            "parameters": {
                "type": "object",
                "properties": {
                    "客廳燈開關狀態": {
                        "type": "string",
                        "description": "客廳電燈的狀態",
                        "enum": ["關", "開"]
                    },
                    "廚房燈開關狀態": {
                        "type": "string",
                        "description": "廚房電燈的狀態",
                        "enum": ["關", "開"]
                    },
                    "主臥燈開關狀態": {
                        "type": "string",
                        "description": "房間電燈的狀態",
                        "enum": ["關", "開"]
                    },
                    "客臥燈開關狀態": {
                        "type": "string",
                        "description": "房間電燈的狀態",
                        "enum": ["關", "開"]
                    },
                    "廁所燈開關狀態": {
                        "type": "string",
                        "description": "房間電燈的狀態",
                        "enum": ["關", "開"]
                    },
                    "玄關燈開關狀態": {
                        "type": "string",
                        "description": "房間電燈的狀態",
                        "enum": ["關", "開"]
                    },
               #     "亮度" : {
               #         "type": "integer",
               #         "description": "電燈的亮度，0到100",
               #     },
                },
               # "required": ["location"],
            },
        },
      
    ]
    response = openai.ChatCompletion.create(
        model="gpt-3.5-turbo",
        messages=messages,
        functions=functions,
        function_call="auto", 
    )
    response_message = response["choices"][0]["message"]


    if response_message.get("function_call"):

        function_name = response_message["function_call"]["name"]
        return response_message



respone = run_conversation(input())



print(eval(respone["function_call"]["arguments"]))


