
import openai
import json

key1 = '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'
key2 = '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'
openai.api_key =  key1

print(openai.Model.list())